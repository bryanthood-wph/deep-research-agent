import os
import re
import html
import datetime
from typing import Dict, Optional

import sendgrid
from sendgrid.helpers.mail import Email, Mail, Content, To
from agents import Agent, function_tool, ModelSettings

BRAND = {
    "wordmark": "B. Colby Hood MBA",
    "accent": "#f97316",
    "text":   "#111827",
    "muted":  "#6b7280",
    "bg":     "#ffffff",
    "card":   "#f9fafb",
    "button_text": "#ffffff",
    "link":   "#0ea5e9",
    "site_url": "https://bryanthood-wph.github.io/",
    "linkedin_url": "https://www.linkedin.com/in/bryanthood",
    "github_url": "https://github.com/bryanthood-wph",
}

EMAIL_TEMPLATE = """<!doctype html>
<html lang="en"><head><meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="x-ua-compatible" content="ie=edge"><title>{subject}</title></head>
<body style="margin:0;padding:0;background:{bg};color:{text};font-family:-apple-system, Segoe UI, Roboto, Helvetica, Arial, sans-serif;">
<div style="display:none;overflow:hidden;line-height:1px;opacity:0;max-height:0;max-width:0;">{preheader}</div>
<table role="presentation" cellpadding="0" cellspacing="0" width="100%"><tr><td align="center" style="padding:24px;">
<table role="presentation" width="640" cellpadding="0" cellspacing="0" style="width:640px;max-width:640px;">
<tr><td style="padding:16px 24px;background:{bg};">
  <div style="font-weight:700;font-size:18px;color:{text};">{wordmark}</div>
  <div style="font-size:12px;color:{muted};">AI automation • Finance ops • Analytics engineering</div>
</td></tr>
<tr><td style="padding:20px 24px;background:{card};border-radius:8px;">
  <div style="font-size:20px;font-weight:700;margin-bottom:8px;color:{text};">{hero_title}</div>
  <div style="font-size:14px;color:{muted};">{hero_sub}</div>
</td></tr>
<tr><td style="padding:24px;">
  <div style="font-size:16px;font-weight:700;margin-bottom:8px;">Action Board</div>
  <ul style="padding-left:18px;margin:0;">{actions_html}</ul>
  {cta_html}
</td></tr>
<tr><td style="padding:0 24px 8px;">
  <h2 style="font-size:18px;margin:0 0 8px;color:{text};">Executive Summary</h2>
  {exec_summary_html}
</td></tr>
<tr><td style="padding:8px 24px;">
  <h2 style="font-size:18px;margin:0 0 8px;color:{text};">Main Findings</h2>
  {findings_html}
</td></tr>
<tr><td style="padding:8px 24px 16px;">
  <h2 style="font-size:18px;margin:0 0 8px;color:{text};">Sources</h2>
  {sources_html}
</td></tr>
<tr><td style="padding:20px 24px;border-top:1px solid #e5e7eb;">
  <table role="presentation" width="100%"><tr>
    <td style="font-size:12px;color:{muted};">
      © {year} {wordmark} —
      <a href="{linkedin_url}" style="color:{link};text-decoration:none;">LinkedIn</a> •
      <a href="{github_url}" style="color:{link};text-decoration:none;">GitHub</a> •
      <a href="{site_url}" style="color:{link};text-decoration:none;">Website</a>
    </td>
    <td align="right" style="font-size:12px;"><a href="{site_url}" style="color:{link};text-decoration:none;">View site</a></td>
  </tr></table>
</td></tr>
</table></td></tr></table>
</body></html>"""

H2 = re.compile(r"^\s{0,3}##\s+(.*)$", re.M)

def _section(md: str, title: str) -> str:
    """Capture content under heading with flexible matching."""
    # Try multiple variations and header levels
    variations = [title]
    
    # Add common variations
    if title == "Action Board":
        variations.extend(["Actions", "Action Items", "Top Actions", "Action Plan"])
    elif title == "Executive Summary":
        variations.extend(["Executive summary", "Summary", "Overview"])
    elif title == "Main Findings":
        variations.extend(["Findings", "Key Findings", "Main findings"])
    elif title == "Sources":
        variations.extend(["References", "Links", "Source Links"])
    
    # Try each variation with multiple header levels
    for variant in variations:
        for hashes in ["###", "##", "#"]:
            # Case-insensitive, flexible whitespace
            pat = re.compile(
                rf"^\s{{0,3}}{re.escape(hashes)}\s+{re.escape(variant)}\s*$([\s\S]*?)(^\s{{0,3}}#{{{len(hashes)},}}\s+|\Z)",
                re.M | re.I
            )
            m = pat.search(md + "\n## END\n")
            if m and m.group(1).strip():
                return m.group(1).strip()
    
    return ""

def _actions(md: str) -> list[str]:
    """Extract action lines from Action Board section."""
    block = _section(md, "Action Board")
    
    # If we found a section, extract lines
    if block:
        lines = [ln.strip("-• ").strip() for ln in block.splitlines() if ln.strip()]
        # Prefer lines with KPI/Target, fallback to any list items
        action_lines = [ln for ln in lines if "KPI:" in ln and "Target:" in ln]
        if action_lines:
            return action_lines[:5]
        # Fallback: any non-empty lines that look like actions
        return [ln for ln in lines if len(ln) > 10][:5]
    
    # Fallback: scan entire document for action-like patterns
    lines = [ln.strip("-• ").strip() for ln in md.splitlines() if ln.strip()]
    action_lines = [ln for ln in lines if "KPI:" in ln and "Target:" in ln]
    return action_lines[:5] if action_lines else []

def _md_to_html_list(md_block: str) -> str:
    """Convert simple bullets to <ul><li>."""
    if not md_block: return "<p style='color:#6b7280'>No data.</p>"
    items = []
    for ln in md_block.splitlines():
        t = ln.strip()
        if not t: continue
        t = t.lstrip("-• ").strip()
        items.append(f"<li style='margin-bottom:8px;'>{html.escape(t)}</li>")
    return "".join(items) if items else f"<p>{html.escape(md_block)}</p>"

def _md_to_html_paras(md_block: str) -> str:
    """Very light conversion: split by lines, wrap paras and keep bullets as plain text."""
    if not md_block: return "<p style='color:#6b7280'>No data.</p>"
    parts = [p.strip() for p in re.split(r"\n\s*\n", md_block.strip()) if p.strip()]
    out = []
    for p in parts:
        if p.startswith("-") or p.startswith("•"):
            out.append(f"<ul style='padding-left:18px;margin:0;'>{_md_to_html_list(p)}</ul>")
        else:
            out.append(f"<p style='margin:0 0 8px 0;'>{html.escape(p)}</p>")
    return "".join(out)

def _first_line_text(md: str) -> str:
    """Preheader seed from first action or first exec bullet."""
    # Try actions first
    acts = _actions(md)
    if acts and acts[0]:
        return acts[0][:120]
    
    # Try executive summary
    es = _section(md, "Executive Summary")
    if es:
        lines = [x.strip() for x in es.splitlines() if x.strip()]
        if lines:
            return lines[0].lstrip("-• ").strip()[:120]
    
    # Fallback: first substantial line from anywhere
    lines = [ln.strip() for ln in md.splitlines() if ln.strip() and not ln.strip().startswith("#")]
    for ln in lines:
        cleaned = ln.lstrip("-• ").strip()
        if len(cleaned) > 20:  # Meaningful content
            return cleaned[:120]
    
    return "Brief ready."

def render_branded_email_html(report_md: str, subject: str, cta_url: Optional[str] = None, cta_label: str = "View Full Report") -> str:
    """Wrap the parsed markdown sections into the branded HTML template."""
    actions = _actions(report_md)
    actions_html = "".join(f"<li style='margin-bottom:8px;'>{html.escape(a)}</li>" for a in actions) or "<li>No actions provided.</li>"
    cta_html = f"<div style='padding-top:16px;'><a href='{html.escape(cta_url)}' style='display:inline-block;background:{BRAND['accent']};color:{BRAND['button_text']};text-decoration:none;font-weight:700;font-size:14px;padding:12px 16px;border-radius:6px;'>{html.escape(cta_label)}</a></div>" if cta_url else ""
    exec_summary_html = _md_to_html_paras(_section(report_md, "Executive Summary"))
    findings_html     = _md_to_html_paras(_section(report_md, "Main Findings"))
    sources_html      = _md_to_html_list(_section(report_md, "Sources"))

    hero_title = subject or "SMB Decision Brief"
    hero_sub   = "Action-first summary with measurable KPIs."
    preheader  = _first_line_text(report_md)
    year       = str(datetime.date.today().year)

    html_out = EMAIL_TEMPLATE.format(
        subject=html.escape(subject or "Brief"),
        preheader=html.escape(preheader),
        hero_title=html.escape(hero_title),
        hero_sub=html.escape(hero_sub),
        actions_html=actions_html,
        exec_summary_html=exec_summary_html,
        findings_html=findings_html,
        sources_html=sources_html,
        cta_html=cta_html,
        year=year,
        **BRAND
    )
    return html_out

def mask_email(email: str) -> str:
    """Mask email for privacy: a****@domain.com"""
    try:
        local, domain = email.split('@')
        if len(local) <= 1:
            masked_local = local[0] + "****"
        else:
            masked_local = local[0] + "****"
        return f"{masked_local}@{domain}"
    except Exception:
        return "****@****.***"


def send_email_direct(subject: str, html_body: str, to_email: str) -> Dict[str, str]:
    """Send an email with the given subject and HTML body (direct call version)"""
    # html_body comes as Markdown from the orchestrator (report.markdown_report)
    # Convert to branded HTML using our template
    html_content = render_branded_email_html(
        report_md=html_body,
        subject=subject,
        cta_url=BRAND["site_url"],
        cta_label="View Portfolio"
    )
    
    # Strip CRLF from subject for safety
    subject = subject.replace('\r', '').replace('\n', '')
    
    sg = sendgrid.SendGridAPIClient(api_key=os.environ.get("SENDGRID_API_KEY"))
    from_email = Email("colby@colbyhoodconsulting.com")  # put your verified sender here
    to_email_obj = To(to_email)
    content = Content("text/html", html_content)  # Now it's branded HTML
    mail = Mail(from_email, to_email_obj, subject, content).get()
    response = sg.client.mail.send.post(request_body=mail)
    
    # Mask email for logging
    masked = mask_email(to_email)
    print(f"Email sent to {masked}, status: {response.status_code}")
    return {"status": "sent", "to": masked}


@function_tool
def send_email(subject: str, html_body: str) -> Dict[str, str]:
    """Send an email with the given subject and HTML body"""
    return send_email_direct(subject, html_body)


INSTRUCTIONS = """Produce ONE HTML email from a provided report.

Order:
- Subject (clear)
- "Action Board" first as an HTML list (each line uses the standard action format).
- Then the rest of the report as semantic HTML (h1–h3, p, ul/ol, a). No commentary.

Tooling: call the send_email tool exactly once with subject, html_body.

No chain-of-thought. US English.

Example <li>:
<li>Sales Call lapsed quotes — KPI: closes Target: +4 by 2025-11-18 (B:0, Src:CRM; Effort:M; Impact:H) [Season:year-end budgets, Lead:14d]</li>"""

email_agent = Agent(
    name="Email agent",
    instructions=INSTRUCTIONS,
    tools=[send_email],
    model="gpt-4o-mini",
    model_settings=ModelSettings(max_output_tokens=200, temperature=0.2),
)
