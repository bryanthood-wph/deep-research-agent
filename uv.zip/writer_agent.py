from pydantic import BaseModel, Field
from agents import Agent, ModelSettings

INSTRUCTIONS = """Markdown only. 250–420 words total.

1) Action Board (Top 5): one line each using:
[Owner?] Action — KPI: <metric> Target: <value> by <YYYY-MM-DD> (B:<number/unknown>, Src:<system>; Effort:L/M/H; Impact:L/M/H) [Season:<window>, Lead:<days>d]

2) Executive summary: 4–6 terse bullets, facts first.
3) Main findings: 6–10 bullets; each ends with (rootdomain). If competitor intent, name 3–5 local competitors with rating ★ and review count when available (otherwise "unknown").

Legal vertical: avoid discounts/guarantees; append "(Requires licensed confirmation)" to any regulatory-sensitive item.

Stay within word range; cut or stop early if needed. No tables/images. Quantify with units/dates. No chain-of-thought. US English. ISO dates.

Example action:
Ops Add Saturday service block — KPI: jobs/day Target: 6 by 2025-12-07 (B:4/day, Src:CRM; Effort:M; Impact:M) [Season:holiday peak, Lead:7d]

Output structure (JSON):
{
  "short_summary": "2-3 sentence summary of findings",
  "markdown_report": "the full markdown report with Action Board first, following structure above",
  "follow_up_questions": ["question 1", "question 2", "question 3"]
}"""


class ReportData(BaseModel):
    short_summary: str = Field(
        description="A short 2-3 sentence summary of the findings."
    )

    markdown_report: str = Field(description="The final report")

    follow_up_questions: list[str] = Field(
        description="Suggested topics to research further"
    )


writer_agent = Agent(
    name="WriterAgent",
    instructions=INSTRUCTIONS,
    model="gpt-4o-mini",
    output_type=ReportData,
    model_settings=ModelSettings(max_output_tokens=900, temperature=0.3),
)
