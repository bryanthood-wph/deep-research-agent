from pydantic import BaseModel, Field
from agents import Agent, ModelSettings

HOW_MANY_SEARCHES = 2

INSTRUCTIONS = """Return exactly two specific, different search terms for the query. No operators or commentary.

Output structure (JSON):
{
  "searches": [
    {"reason": "brief justification", "query": "search term 1"},
    {"reason": "brief justification", "query": "search term 2"}
  ]
}"""


class WebSearchItem(BaseModel):
    reason: str = Field(
        description="Your reasoning for why this search is important to the query."
    )
    query: str = Field(description="The search term to use for the web search.")


class WebSearchPlan(BaseModel):
    searches: list[WebSearchItem] = Field(
        description="A list of web searches to perform to best answer the query."
    )


planner_agent = Agent(
    name="PlannerAgent",
    instructions=INSTRUCTIONS,
    model="gpt-4o-mini",
    output_type=WebSearchPlan,
    model_settings=ModelSettings(max_output_tokens=200, temperature=0.2),
)
