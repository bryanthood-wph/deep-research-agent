﻿"""
Preset texts and a helper to build writer instructions for SMB Decision Briefs.

Functions:
- writer_instructions(template: str, biz: str, location: str) -> str
"""

TEMPLATES: dict[str, str] = {
    "Competitor Snapshot": (
        "Top 5 local competitors near {location}. Pricing, offers, and site SEO notes. "
        "End with 5 actions for the next 14 days."
    ),
    "Local SEO Audit": (
        "Audit {biz} in {location}: NAP consistency, priority keywords, Google Business Profile, "
        "citations, and site speed. Prioritize fixes by effort and impact."
    ),
    "Grant Opportunities": (
        "Active grants for {biz} in {location}: eligibility, deadlines, award sizes, and a prep checklist."
    ),
}

def writer_instructions(template: str, biz: str, location: str) -> str:
    ctx = TEMPLATES[template].format(biz=biz, location=location)
    return (
        f"SMB Decision Brief.\n\n"
        f"Context: {ctx}\n\n"
        "1) Action Board (7/30/90):\n"
        "- Next 7 Days\n"
        "- Next 30 Days\n"
        "- Next 90 Days\n"
        "List actions under each using:\n"
        "[Owner?] Action — KPI: <metric> Target: <value> by <YYYY-MM-DD> (B:<number/unknown>, Src:<system>; Effort:L/M/H; Impact:L/M/H) [Season:<window>, Lead:<days>d]\n\n"
        "2) Executive summary: 5 bullets.\n"
        "3) Main brief: markdown sections (## headings); concise paragraphs/bullets; quantify prices, timelines, counts.\n"
        "If competitor snapshot, add \"Local Competitors\" with 3–5 names + rating ★ + review count when available (no fabrication).\n\n"
        "Legal vertical: avoid discounts/guarantees; tag sensitive items \"(Requires licensed confirmation)\".\n\n"
        "Sources: bullets with links or root domains; include publication or access date if visible.\n"
        "Keep total under 500 words across sections. Stay within word range; cut or stop early if needed. No chain-of-thought. US English. ISO dates.\n\n"
        "Example 7-day action:\n"
        "Owner Update GBP holiday hours — KPI: direction requests Target: +12% by 2025-11-25 (B:210/mo, Src:GBP; Effort:L; Impact:M) [Season:Thanksgiving, Lead:3d]\n\n"
        "Output structure (JSON):\n"
        "{\n"
        '  "short_summary": "2-3 sentence summary",\n'
        '  "markdown_report": "the full markdown brief with 7/30/90 Action Board first",\n'
        '  "follow_up_questions": ["question 1", "question 2"]\n'
        "}"
    )
