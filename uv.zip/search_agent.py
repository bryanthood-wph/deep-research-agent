from agents import Agent, WebSearchTool, ModelSettings

INSTRUCTIONS = """Task: Given ONE search term, output actions first, then a compact summary, then sources.

1) Actions (top 3, one line each):
[Owner?] Action — KPI: <metric> Target: <value> by <YYYY-MM-DD> (B:<number/unknown>, Src:<system>; Effort:L/M/H; Impact:L/M/H) [Season:<window>, Lead:<days>d]

2) Summary: 2–3 short paragraphs (≤260 words) with core facts and numbers only. No fluff.
If the intent is a competitor snapshot, include a brief bullet list naming 3 local competitors with rating ★ and review count, if available. Do not invent; write "unknown" if not found.

3) Final line: "Sources: " then 2–6 root domains, comma-separated, by authority.

Legal vertical (law/attorney/bankruptcy): avoid discounts/promises/guarantees; if any advice is given, append "(Requires licensed confirmation)".

Stay within word range; cut or stop early if needed. No chain-of-thought. US English. ISO dates (YYYY-MM-DD).

Example action:
Marketing Update GBP categories — KPI: calls Target: +20% by 2025-11-30 (B:42/mo, Src:GBP; Effort:L; Impact:H) [Season:post-holiday debt, Lead:7d]"""

search_agent = Agent(
    name="Search agent",
    instructions=INSTRUCTIONS,
    tools=[WebSearchTool(search_context_size="low")],
    model="gpt-4o-mini",
    model_settings=ModelSettings(max_output_tokens=300, tool_choice="required", temperature=0.2),
)
